//
//  AppDelegate.h
//  JYWeb
//
//  Created by XXX on 2019/7/1.
//  Copyright © 2019年 *. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

