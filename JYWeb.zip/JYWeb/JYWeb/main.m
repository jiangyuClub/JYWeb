//
//  main.m
//  JYWeb
//
//  Created by XXX on 2019/7/1.
//  Copyright © 2019年 *. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
