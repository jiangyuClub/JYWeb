//
//  ViewController.m
//  JYWeb
//
//  Created by XXX on 2019/7/1.
//  Copyright © 2019年 *. All rights reserved.
//

#import "ViewController.h"
#import <JYWebSDK/WebImportHeader.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 100, 100, 40);
    btn.backgroundColor = [UIColor redColor];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(doBtn) forControlEvents:UIControlEventTouchUpInside];
}

- (void)doBtn {
    IQJWebViewController *vc = [[IQJWebViewController alloc] init];
    [vc loadRequestWithUrl:@"https://www.baidu.com"];
    [self.navigationController pushViewController:vc animated:YES];
}


@end
