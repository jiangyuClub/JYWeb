//
//  IQJWebUtil.m
//  XXX
//
//  Created by XXX on 2019/3/13.
//  Copyright © 2019年 XXX. All rights reserved.
//

#import "IQJWebUtil.h"

@implementation IQJWebUtil

#pragma mark- 解析/数据转换
#pragma mark json串转dic或者string
+ (id)getDicOrStringFromJson:(NSString *)jsonString {
    if (!jsonString ||
        ![jsonString isKindOfClass:NSString.class]) {
        return nil;
    }
    if ([jsonString isEqualToString:@""]) {
        return jsonString;
    }
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    if (!jsonData) {
        return jsonString;
    }
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingAllowFragments
                                                          error:&err];
    if(err) {
        return jsonString;
    }
    return dic;
}

#pragma mark json串转dic
+ (NSDictionary *)getDictionaryFromJson:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    if (jsonData == nil) {
        return nil;
    }
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingAllowFragments
                                                          error:&err];
    if(err) {
        return nil;
    }
    return dic;
}

#pragma mark object转json串
+ (NSString *)getJsonFromObject:(id)dict {
    NSString *jsonString = nil;
    NSError *error;
    
    if (![NSJSONSerialization isValidJSONObject:dict]) {
        return @"{}";
    }
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:&error];
    if (! jsonData) {
        return @"{}";
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}

#pragma mark Url的参数转换成字典
+ (NSDictionary *)getDicWithUrlQuery:(NSString *)urlQuery {
    NSMutableDictionary *queryDic = nil;
    NSArray *queryArray = [urlQuery componentsSeparatedByString:@"&"];
    if (queryArray && [queryArray isKindOfClass:[NSArray class]] && queryArray.count > 0) {
        queryDic = [NSMutableDictionary dictionary];
        for (NSString *subString in queryArray) {
            NSArray *subArray = [subString componentsSeparatedByString:@"="];
            if ([subArray isKindOfClass:[NSArray class]] && subArray.count > 1) {
                NSMutableString *value = [[NSMutableString alloc] initWithString:subArray[1]];
                for (NSInteger i = 2; i < subArray.count; i ++) {
                    [value appendFormat:@"=%@", subArray[i]];
                }
                [queryDic setObject:[NSString stringWithString:value] forKey:subArray[0]];
            }
        }
    }
    return queryDic;
}

@end
