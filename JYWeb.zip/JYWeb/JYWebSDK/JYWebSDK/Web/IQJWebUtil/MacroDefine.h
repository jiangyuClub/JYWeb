//
//  MacroDefine.h
//  CinCommon
//
//  Created by XXX on 15/7/15.
//  Copyright (c) 2015年 XXX. All rights reserved.
//




#define SINGLE_LINE_WIDTH           (1.0f / [UIScreen mainScreen].scale)
#define SINGLE_LINE_ADJUST_OFFSET   ((1.0f / [UIScreen mainScreen].scale) / 2)

#define kPushAnimationTime       0.2
#define kPopAnimationTime        0.2
#define kMaxPageSize             10000

#define kRecordsSize             20

/* 宏两数字取大小 */
#define kGetMax(x, y, z)         ((z) > (MAX((x), (y))) ? (z) : (MAX((x), (y))))
#define kGetMin(x, y, z)         ((z) < (MIN((x), (y))) ? (z) : (MIN((x), (y))))


/***  UI部分宏定义  ***/
/* 屏幕尺寸 */
#define IPHONE4                 ((round([[UIScreen mainScreen] bounds].size.height) == 480)? YES:NO)
#define IPHONE5                 ((round([[UIScreen mainScreen] bounds].size.height) == 568)? YES:NO)
#define IPHONE6                 ((round([[UIScreen mainScreen] bounds].size.height) == 667)? YES:NO)
#define IPHONE6P                ((round([[UIScreen mainScreen] bounds].size.height) == 736)? YES:NO)
//#define IPHONEX                 ((round([[UIScreen mainScreen] bounds].size.height) == 812)? YES:NO)
#define ScreenWidth320          ((round([[UIScreen mainScreen] bounds].size.width) == 320)? YES:NO)
#define ScreenWidth375          ((round([[UIScreen mainScreen] bounds].size.width) == 375)? YES:NO)
#define ScreenWidth414          ((round([[UIScreen mainScreen] bounds].size.width) == 414)? YES:NO)
#define ScreenWidth             ([[UIScreen mainScreen] bounds].size.width)
#define ScreenHeight            ([[UIScreen mainScreen] bounds].size.height)
#define Onepixel                1.0 / [UIScreen mainScreen].scale

//判断刘海屏来确定是否是iPhoneX及以上
#define IPHONEX  ({\
                    int tmp = 0;\
                    if (@available(iOS 11.0, *)) {\
                        if ([[UIApplication sharedApplication] delegate].window.safeAreaInsets.bottom > 0.0) {\
                            tmp = 1;\
                        }\
                    }\
                    tmp;\
                })

//根据比例换算(Result / Value = BaseResult / BaseValue)
#define kFitterValue(Value, BaseResult, BaseValue)       ((BaseResult) / (BaseValue) * (Value))
//垂直方向(默认UI按照iPhone6尺寸375*667为基准)
#define kFitterVerticalValue(VerticalValue)              kFitterValue(VerticalValue, ScreenHeight, 667)
//水平方向
#define kFitterHorizontalValue(HorizontalValue)          kFitterValue(HorizontalValue, ScreenWidth, 375)

/* 公共间隔 */
#define kTopSafeAreaInsetsHeight     (IPHONEX ? 44 : 20) //顶部安全区偏移：44 状态栏位置
#define kBottomSafeAreaInsetsHeight  (IPHONEX ? 34 : 0)  //底部安全区偏移：34 iPhoneX传感器
#define kNavigationBarHeight         (IPHONEX ? 88 : 64) //导航栏高度
#define kTopSafeAreaIphoneXMoreHei   (IPHONEX ? 24 : 0)  //iPhoneX顶部安全区状态栏高出部分24
#define kStatusBarHeight         0
#define kTabBarHeight            (54 + kBottomSafeAreaInsetsHeight) //tabBar高度
#define kScrollRefreshHeight     45.0f      //刷新滚动高度
#define kSeparateLineHeight      Onepixel   //分割线粗
#define kLeftCommonMargin        (ScreenWidth320 ? 10 : 15)//左右侧边缘间隔
#define kLeftRightMargin        (ScreenWidth320 ? 20 : 20)//左右侧边缘间隔
#define kLeftHomeMargin          20     //Home页侧边缘间隔
#define kLeftBigMargin           15     //左右侧边缘间隔15
#define kTopCommonMargin         15.0f  //上侧边缘间隔
#define kGapCommon               5.0f   //上下间隔
#define kButtonHeight            49.0f  //类似购买大按钮高度

#define kLeftFitter              kFitterHorizontalValue(15)
#define kCommonMargin            20
#define kNewLeftFitter           kFitterHorizontalValue(20)

#define kProportion             (ScreenWidth/(750.0f/2.0f)) //图片宽度与高度比例

#define SET_CONTENT_BACKGROUND_IMAGE(imageName,top,left,bottom,right)  [[UIImage imageNamed:(imageName)] resizableImageWithCapInsets:UIEdgeInsetsMake((top),(left),(bottom),(right)) resizingMode:UIImageResizingModeStretch] //拉伸图片
#define SET_CONTENT_BACKGROUND_IMAGEOBJECT(image,top,left,bottom,right)  [(image) resizableImageWithCapInsets:UIEdgeInsetsMake((top),(left),(bottom),(right)) resizingMode:UIImageResizingModeStretch] //拉伸图片

#define LRNotificationCenter [NSNotificationCenter defaultCenter]

/*** 宏方法 ***/
/* 系统版本判断 */
#define iOS_Version                                 ([[[UIDevice currentDevice] systemVersion] floatValue])
#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)





#define kUserID                 [[ClientManager sharedClientManager] getUserId]
#define kLoginState             (kUserID > 0 ? YES : NO)
#define kClientModel            [[ClientManager sharedClientManager] clientModel]
#define kGlobalConfigModel      [[ClientManager sharedClientManager] globalConfigModel]

/*** 在线客服URL ***/
#define kOnlineServiceWebUrl      @"https://www.sobot.com/chat/h5/index.html?sysNum=9e30de40563c4d95af9fe701d8e9519a&source=2" //V4.5.0由百度商桥换成智齿，url由服务器获取，取不到用这个url

#define kXXXPhoneNumber     @"tel://4008128808"
#define kXXXPhoneNumberDis  @"400-812-8808"
//宣传语调整
#define kShortExplain  @"预期年化结算利率不等于实际收益，以实际收益为准。"

#define AFN_MANAGER [AQJNetworkManager sharedManager]
#define AFN_CONFIG [AQJNetworkConfig sharedConfig]

//微信服务号
#define kWXServeId @"IQJVIP"

//随机红包加载类型page
#define kRandomRedPage        [[[ClientManager sharedClientManager] getRandomRedPacketInfo] integerForKeyInIQJ:@"page"]
#define kRandomRedBagUrl      [[[ClientManager sharedClientManager] getRandomRedPacketInfo] stringForKeyInIQJ:@"redBagUrl"]


#define kDetailTabbarHeight   50  //产品详情页tab高度
#define kDetailSlideHeight    50  //产品详情页滑块高度

#define RootNC                      [RootNavigationController rootNavigationController]
#define RootTC                      [RootTabBarController rootTabBarController]

//判断数组和字典不为空
#define IsNOTNullOrEmptyOfArray(_ARRAY___) (_ARRAY___ && [_ARRAY___ isKindOfClass:[NSArray class]] && [_ARRAY___ count])
#define IsNOTNullOrEmptyOfDictionary(_DICTIONARY___) (_DICTIONARY___ && [_DICTIONARY___ isKindOfClass:[NSDictionary class]] && [_DICTIONARY___ count])



#define kCalendarCellWidth          (((NSInteger)((ScreenWidth/7.0f)*2.0f))/2.0f)
#define kCalendarCellHeight         ((((NSInteger)((60.0)*(kCalendarCellWidth/53.5)*2.0f))/2.0f))




/**
 webView类型
 */
typedef NS_ENUM(NSInteger, IQJWebViewType) {
    IQJWebViewType_OLDWeb = 0, /** 老板web */
    IQJWebViewType_UIWeb = 1,  /** 新版UIWeb */
    IQJWebViewType_WKWeb = 2,  /** 新版WKWeb */
};

typedef void (^VoidBlock)(void);
