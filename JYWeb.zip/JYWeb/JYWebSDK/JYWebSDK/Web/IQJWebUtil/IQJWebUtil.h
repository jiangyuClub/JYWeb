//
//  IQJWebUtil.h
//  XXX
//
//  Created by XXX on 2019/3/13.
//  Copyright © 2019年 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IQJWebUtil : NSObject

//json串转dic或者string
+ (id)getDicOrStringFromJson:(NSString *)jsonString;

//json串转dic
+ (NSDictionary *)getDictionaryFromJson:(NSString *)jsonString;

//object转json串
+ (NSString *)getJsonFromObject:(id)dict;

//Url的参数转换成字典
+ (NSDictionary *)getDicWithUrlQuery:(NSString *)urlQuery;

@end
