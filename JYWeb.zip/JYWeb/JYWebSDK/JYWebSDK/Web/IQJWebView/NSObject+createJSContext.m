//
//  NSObject+createJSContext.m
//  iqianjin
//
//  Created by jiangyu on 2019/6/10.
//  Copyright © 2019年 iqianjin. All rights reserved.
//

#import "NSObject+createJSContext.h"

@implementation NSObject (createJSContext)

- (void)webView:(id)webView didCreateJavaScriptContext:(id)ctx forFrame:(id)frame
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"WebViewDidCreateJavaScriptContext" object:ctx];
}

@end
