//
//  IQJWebViewHandler.h
//  XXX
//
//  Created by XXX on 2018/12/24.
//  Copyright © 2018年 XXX. All rights reserved.
//  Web浏览器View管理器
//  切换UIWebview和WKWebview，处理代理事件，管理UserAgent和Cookies等

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>
#import "WebImportHeader.h"

/**
 WebView管理器，系统代理回调
 */
@protocol IQJWebViewDelegate <NSObject>

@optional
- (BOOL)iqjWebViewShouldStartLoadURL:(NSURL *)URL;

- (void)iqjWebViewDidStartLoadURL:(NSURL *)URL;

- (void)iqjWebViewDidFinishLoadURL:(NSURL *)URL;

- (void)iqjWebViewURL:(NSURL *)URL didFailLoadWithError:(NSError *)error;

@end


@interface IQJWebViewHandler : NSObject

@property (nonatomic, assign) IQJWebViewType webViewType;   /** webView类型 */
@property (nonatomic, weak) id<IQJWebViewDelegate>delegate; /** webview代理事件 */
@property (nonatomic, strong) UIWebView *uiWebView;         /**  */
@property (nonatomic, strong) WKWebView *wkWebView;         /**  */

@property (nonatomic, copy, readonly) NSString *currentUrl; /** 当前url */
@property (nonatomic, copy, readonly) NSString *title;      /** web加载完成取的title */
@property (nonatomic, assign, readonly) BOOL canGoBack;     /** 浏览器canGoBack */
@property (nonatomic, assign, readonly) BOOL isLoading;     /** 浏览器loading */

/**
 初始化webview
 */
- (void)initWebViewOnView:(UIView *)view;

/**
 设置隐藏导航栏
 */
- (void)hideNavBar:(NSInteger)isHideNavBar;

/**
 设置Cookies
 */
- (void)setCookiesUrl:(NSString *)url appToken:(NSString *)appToken webInfoArray:(NSArray *)webInfoArray;

/**
 发起请求
 */
- (void)loadRequestWithUrl:(NSString *)urlStr;

- (void)loadHtml:(NSString *)html;

- (void)goBack;

/**
 清除web缓存
 */
- (void)removeCache;

- (void)resetCurrentUrl:(NSString *)url;

@end

