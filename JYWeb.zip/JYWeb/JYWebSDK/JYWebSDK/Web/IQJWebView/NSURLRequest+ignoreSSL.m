//
//  NSURLRequest+ignoreSSL.m
//  iqianjin
//
//  Created by jiangyu on 2019/6/27.
//  Copyright © 2019年 iqianjin. All rights reserved.
//

#import "NSURLRequest+ignoreSSL.h"

@implementation NSURLRequest (ignoreSSL)

+(BOOL)allowsAnyHTTPSCertificateForHost:(NSString*)host {
    return YES;
}

@end
