//
//  IQJWebViewHandler.m
//  XXX
//
//  Created by XXX on 2018/12/24.
//  Copyright © 2018年 XXX. All rights reserved.
//

#import "IQJWebViewHandler.h"

static NSString *const UserAgentAppendStr = @" XXX";                    //UserAgent拼接字符串
static NSString *const UserAgentUserDefaultKey = @"UserAgentUserDefaultKey"; //本地存储UserAgent的Key

@interface IQJWebViewHandler ()<UIWebViewDelegate, WKUIDelegate, WKNavigationDelegate>

@property (nonatomic, copy) NSString *appToken;           /** cookies数据 */
@property (nonatomic, copy) NSArray *webInfoArray;        /** cookies数据2 */

@end

@implementation IQJWebViewHandler

- (instancetype)init {
    self = [super init];
    if (!self) {
        return nil;
    }
    return self;
}

#pragma mark 初始化webview
- (void)initWebViewOnView:(UIView *)view {
    if (_webViewType == IQJWebViewType_UIWeb) {
        //如浏览器由WKWeb切换成UIWeb，则先移除WKWeb在加载UIWeb（注意此处不能用self.wkWebView）
        if (_wkWebView && [view.subviews containsObject:_wkWebView]) {
            [_wkWebView removeFromSuperview];
        }
        [view addSubview:self.uiWebView];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        if (_uiWebView && [view.subviews containsObject:_uiWebView]) {
            [_uiWebView removeFromSuperview];
        }
        [view addSubview:self.wkWebView];
    }
}


#pragma mark- Methods
#pragma mark 设置隐藏导航栏
- (void)hideNavBar:(NSInteger)isHideNavBar {
    if (_webViewType == IQJWebViewType_UIWeb) {
        self.uiWebView.top = isHideNavBar ? kTopSafeAreaInsetsHeight : kNavigationBarHeight;
        self.uiWebView.height = ScreenHeight - self.uiWebView.top;
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        self.wkWebView.top = isHideNavBar ? kTopSafeAreaInsetsHeight : kNavigationBarHeight;
        self.wkWebView.height = ScreenHeight - self.wkWebView.top;
    }
}

#pragma mark 获取web标题
- (void)getDocumentTitle {
    if (_webViewType == IQJWebViewType_UIWeb) {
        _title = [self.uiWebView stringByEvaluatingJavaScriptFromString:@"document.title"];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        _title = self.wkWebView.title;
    }
}

#pragma mark 获取是canGoBack
- (BOOL)canGoBack {
    BOOL goback = NO;
    if (_webViewType == IQJWebViewType_UIWeb) {
        goback = [_uiWebView canGoBack];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        goback = [_wkWebView canGoBack];
    }
    return goback;
}

- (void)goBack {
    if (_webViewType == IQJWebViewType_UIWeb) {
        [_uiWebView goBack];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        [_wkWebView goBack];
    }
}

- (BOOL)isLoading {
    BOOL loading = NO;
    if (_webViewType == IQJWebViewType_UIWeb) {
        loading = [_uiWebView isLoading];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        loading = [_wkWebView isLoading];
    }
    return loading;
}


#pragma mark- 发起请求
- (void)loadRequestWithUrl:(NSString *)urlStr {
    if (!urlStr || urlStr.length <= 0) {
        return;
    }
    _currentUrl = urlStr;
//    NSURL *url = [NSURL URLWithString:urlStr];
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    if (_webViewType == IQJWebViewType_UIWeb) {
//        [self.uiWebView loadRequest:request];
        //testjiang 本地html调试
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"webViewIndex" withExtension:@"html"];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [self.uiWebView loadRequest:request];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        //wkweb获取UserAgent是一个异步方法，需要在更改完成后再发起loadRequest，否则第一次请求UserAgent无效
        [self resetWKWebViewUserAgent:^{
//            [self.wkWebView loadRequest:request];
            NSURL *wkurl = [[NSBundle mainBundle] URLForResource:@"webViewIndex" withExtension:@"html"];
            NSURLRequest *wkrequest = [NSURLRequest requestWithURL:wkurl];
            [self.wkWebView loadRequest:wkrequest];
        }];
    }
}

- (void)loadHtml:(NSString *)html {
    if (!html || html.length <= 0) {
        return;
    }
    if (_webViewType == IQJWebViewType_UIWeb) {
        [self.uiWebView loadHTMLString:html baseURL:nil];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        [self.wkWebView loadHTMLString:html baseURL:nil];
    }
}

- (void)resetCurrentUrl:(NSString *)url {
    _currentUrl = url;
}

#pragma mark- UserAgent
#pragma mark 重置UIWeb UserAgent
//uiweb初始化时修改UserAgent
//userAgent存在NSUserDefaults中，避免反复从浏览器获取
- (void)resetUIWebViewUserAgent {
    NSString *userAgent = [[NSUserDefaults standardUserDefaults] valueForKey:UserAgentUserDefaultKey];
    if (!userAgent) {
        userAgent = [_uiWebView stringByEvaluatingJavaScriptFromString:@"navigator.userAgent"];
    }
    NSString *appendUserAgent = [self webViewUserAgentAppend:userAgent];
    [[NSUserDefaults standardUserDefaults] setValue:appendUserAgent forKey:UserAgentUserDefaultKey];
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{@"UserAgent" : appendUserAgent}];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark 重置WKWeb UserAgent
//wkweb获取UserAgent是一个异步方法，需要在更改完成后再发起loadRequest，否则第一次请求UserAgent无效
- (void)resetWKWebViewUserAgent:(VoidBlock)block {
    NSString *userAgent = [[NSUserDefaults standardUserDefaults] valueForKey:UserAgentUserDefaultKey];
    if (userAgent && [userAgent containsString:UserAgentAppendStr]) {
        [self saveWKUserAgent:userAgent];
        if (block) {
            block();
        }
    } else {
        [self.wkWebView evaluateJavaScript:@"navigator.userAgent"
             completionHandler:^(id _Nullable result, NSError * _Nullable error) {
                 if (result) {
                     NSString *appendUserAgent = [self webViewUserAgentAppend:result];
                     [self saveWKUserAgent:appendUserAgent];
                 }
                 if (block) {
                     block();
                 }
             }];
    }
}

- (void)saveWKUserAgent:(NSString *)appendUserAgent {
    [[NSUserDefaults standardUserDefaults] setValue:appendUserAgent forKey:UserAgentUserDefaultKey];
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{@"UserAgent" : appendUserAgent}];
    [[NSUserDefaults standardUserDefaults] synchronize];
    //NSUserDefaults只是更改了本地的UserAgent，没修改网页的，下面这个函数是9.0之后才出现的
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"9.0")) {
        [self.wkWebView setCustomUserAgent:appendUserAgent];
    } else {
        [self.wkWebView setValue:appendUserAgent forKey:@"applicationNameForUserAgent"];
    }
}

#pragma mark UserAgent拼接XXX并存储
- (NSString *)webViewUserAgentAppend:(NSString *)result {
    NSMutableString *userAgentMStr = [NSMutableString stringWithString:result];
    if (![result containsString:UserAgentAppendStr]) {
        [userAgentMStr appendString:UserAgentAppendStr];
    }
    return userAgentMStr;
}


#pragma mark- Cookies
#pragma mark 设置cookies
- (void)setCookiesUrl:(NSString *)url appToken:(NSString *)appToken webInfoArray:(NSArray *)webInfoArray {
    if (!url) {
        return;
    }
    _currentUrl = url;
    self.appToken = appToken;
    self.webInfoArray = webInfoArray;
    
    //UIWebView的cookies直接设置，WK的cookies要在发起请求前设置
    if (_webViewType == IQJWebViewType_UIWeb) {
        [self resetUIWebViewCookies];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        [self resetWKWebViewCookies];
    }
}
//日志回捞cookie转字符串
- (NSString *)getLoganWebInfoMessage {
    NSString *result = @"";
    if (_webInfoArray && [_webInfoArray isKindOfClass:[NSArray class]] && _webInfoArray.count > 0) {
        
        for (NSInteger i = 0; i < _webInfoArray.count; i ++) {
            NSString *mString = @"";
            NSDictionary *cookieInfoDic = _webInfoArray[i];
            if (!cookieInfoDic || ![cookieInfoDic isKindOfClass:[NSDictionary class]] || cookieInfoDic.count <= 0) {
                continue;
            }
            NSString *cookieName = cookieInfoDic[@"key"];
            NSString *cookieValue = cookieInfoDic[@"val"];
            NSString *cookieDomain = cookieInfoDic[@"domain"];
            NSString *cookiePath = cookieInfoDic[@"path"];
            NSString *cookieExpires = cookieInfoDic[@"expires"];
            NSString *cookieMaxAge = cookieInfoDic[@"max-age"];
            mString = [NSString stringWithFormat:@"key:%@,val:%@,domain:%@,path:%@,expires:%@,max-age:%@",
                       cookieName,
                       cookieValue,
                       cookieDomain,
                       cookiePath,
                       cookieExpires,
                       cookieMaxAge];
            result = [NSString stringWithFormat:@"%@;%@",result,mString];
        }
    }
    return result;
}

#pragma mark 重置UIWeb Cookies
- (void)resetUIWebViewCookies {
    if (!_currentUrl) {
        return;
    }
    [self deleteUIWebCookies];
    
    NSArray *urlArray = [self.currentUrl componentsSeparatedByString:@"/"];
    NSString *prefixStr = urlArray.firstObject;
    NSURL *url = [NSURL URLWithString:self.currentUrl];
    NSString *cookieUrlStr = [NSString stringWithFormat:@"%@//%@/",prefixStr,url.host];
    NSLog(@"*****************种cook的host    ： %@",cookieUrlStr);
//    cookieUrlStr = [AQJWebHostReplaceHandler replaceCookieUrlStr:cookieUrlStr]; //测试环境下摇一摇替换webhost，种cookie
    NSURL *cookieHost = [NSURL URLWithString:cookieUrlStr];
    NSMutableArray *needCookiesArray = [NSMutableArray array];
    if (_appToken && _appToken.length > 0) {
        NSHTTPCookie *webTokenCookie = [NSHTTPCookie cookieWithProperties:@{NSHTTPCookieDomain : [cookieHost host],
                                                                            NSHTTPCookiePath : [cookieHost path],
                                                                            NSHTTPCookieName : @"appToken",
                                                                            NSHTTPCookieValue : _appToken}];
        if (webTokenCookie) {
            [needCookiesArray addObject:webTokenCookie];
        }
    }
    if (_webInfoArray && [_webInfoArray isKindOfClass:[NSArray class]] && _webInfoArray.count > 0) {
        for (NSInteger i = 0; i < _webInfoArray.count; i ++) {
            NSDictionary *cookieInfoDic = _webInfoArray[i];
            if (!cookieInfoDic || ![cookieInfoDic isKindOfClass:[NSDictionary class]] || cookieInfoDic.count <= 0) {
                continue;
            }
            NSString *cookieName = cookieInfoDic[@"key"];
            NSString *cookieValue = cookieInfoDic[@"val"];
            NSString *cookieDomain = cookieInfoDic[@"domain"];
            NSString *cookiePath = cookieInfoDic[@"path"];
            NSString *cookieExpires = cookieInfoDic[@"expires"];
            NSString *cookieMaxAge = cookieInfoDic[@"max-age"];
            if ((!cookieName || cookieName.length <= 0) ||
                (!cookieValue || cookieValue.length <= 0)) {
                continue;
            }
            NSMutableDictionary *cookieDic = [NSMutableDictionary dictionaryWithDictionary:
                                              @{NSHTTPCookieDomain : (cookieDomain && cookieDomain.length > 0 ? cookieDomain : [cookieHost host]),
                                                NSHTTPCookiePath : (cookiePath && cookiePath.length > 0 ? cookiePath : [cookieHost path]),
                                                NSHTTPCookieName : cookieName,
                                                NSHTTPCookieValue : cookieValue}];
            if (cookieExpires && cookieExpires.length > 0) {
                [cookieDic setValue:[NSDate dateWithTimeIntervalSince1970:[cookieExpires longLongValue]/1000] forKey:NSHTTPCookieExpires];
            }
            if (cookieMaxAge && cookieMaxAge.length > 0) {
                [cookieDic setValue:cookieMaxAge forKey:NSHTTPCookieMaximumAge];
            }
            NSHTTPCookie *cookie = [NSHTTPCookie cookieWithProperties:cookieDic];
            if (cookie) {
                [needCookiesArray addObject:cookie];
            }
        }
    }
    if (needCookiesArray && [needCookiesArray isKindOfClass:[NSArray class]] && needCookiesArray.count > 0) {
        NSURL *cookieForUrl = [NSURL URLWithString:cookieUrlStr];
        if (cookieForUrl && [cookieForUrl isKindOfClass:NSURL.class]) {
            [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookies:needCookiesArray forURL:cookieForUrl mainDocumentURL:cookieForUrl];
        }
    }
}

#pragma mark 删除UIWeb Cookies
- (void)deleteUIWebCookies {
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie *cookie in [storage cookies]) {
        [storage deleteCookie:cookie];
    }
}

#pragma mark 重置WKWeb Cookies
- (void)resetWKWebViewCookies {
    if (!_currentUrl) {
        return;
    }
    [self deleteWKWebCookies];
    
    NSMutableString *scriptString = [NSMutableString string];
    NSArray *urlArray = [self.currentUrl componentsSeparatedByString:@"/"];
    NSString *prefixStr = urlArray.firstObject;
    NSURL *url = [NSURL URLWithString:self.currentUrl];
    NSString *cookieUrlStr = [NSString stringWithFormat:@"%@//%@/",prefixStr,url.host];
    NSLog(@"*****************种cook的host    ： %@",cookieUrlStr);
    //    cookieUrlStr = [AQJWebHostReplaceHandler replaceCookieUrlStr:cookieUrlStr]; //测试环境下摇一摇替换webhost，种cookie
    NSURL *cookieHost = [NSURL URLWithString:cookieUrlStr];
    if (_appToken && _appToken.length > 0) {
        NSMutableString *cookieString = [NSMutableString stringWithFormat:@"appToken=%@;", _appToken];
        [cookieString appendFormat:@"domain=%@;",[cookieHost host]];
        [cookieString appendFormat:@"path=%@;",[cookieHost path]];
        [scriptString appendString:[NSString stringWithFormat:@"document.cookie = '%@';", cookieString]];
    }
    if (_webInfoArray && [_webInfoArray isKindOfClass:[NSArray class]] && _webInfoArray.count > 0) {
        for (NSInteger i = 0; i < _webInfoArray.count; i ++) {
            NSDictionary *cookieInfoDic = _webInfoArray[i];
            if (!cookieInfoDic || ![cookieInfoDic isKindOfClass:[NSDictionary class]] || cookieInfoDic.count <= 0) {
                continue;
            }
            NSString *cookieName = cookieInfoDic[@"key"];
            NSString *cookieValue = cookieInfoDic[@"val"];
            NSString *cookieDomain = cookieInfoDic[@"domain"];
            NSString *cookiePath = cookieInfoDic[@"path"];
            NSString *cookieExpires = cookieInfoDic[@"expires"];
            NSString *cookieMaxAge = cookieInfoDic[@"max-age"];
            if ((!cookieName || cookieName.length <= 0) ||
                (!cookieValue || cookieValue.length <= 0)) {
                continue;
            }
            
            NSMutableString *cookieString = [NSMutableString stringWithFormat:@"%@=%@;", cookieName, cookieValue];
            [cookieString appendFormat:@"domain=%@;",cookieDomain];
            [cookieString appendFormat:@"path=%@;",cookiePath];
            if (cookieExpires && cookieExpires.length > 0) {
                [cookieString appendFormat:@"expires=%@;",[NSDate dateWithTimeIntervalSince1970:[cookieExpires longLongValue]/1000]];
            }
            if (cookieMaxAge && cookieMaxAge.length > 0) {
                [cookieString appendFormat:@"max-age=%@;",cookieMaxAge];
            }
            [scriptString appendString:[NSString stringWithFormat:@"document.cookie = '%@';", cookieString]];
        }
    }
    
    WKUserScript *cookieScript = [[WKUserScript alloc] initWithSource:scriptString
                                                        injectionTime:WKUserScriptInjectionTimeAtDocumentStart
                                                     forMainFrameOnly:NO];
    [self.wkWebView.configuration.userContentController addUserScript:cookieScript];
}

#pragma mark 删除WKWeb Cookies
- (void)deleteWKWebCookies {
    [self removeUserScripts];
    
    //这里测试到web页跳转到原生返回后cookies不见了，所以注掉了
//    if (@available(iOS 9.0, *)) {
//        NSSet *cookieTypeSet = [NSSet setWithArray:@[WKWebsiteDataTypeCookies]];
////        NSSet *cookieTypeSet = [WKWebsiteDataStore allWebsiteDataTypes];
//        [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:cookieTypeSet
//                                                   modifiedSince:[NSDate dateWithTimeIntervalSince1970:0]
//                                               completionHandler:^{
//
//        }];
//    } else {
//        NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
//        for (NSHTTPCookie *cookie in [storage cookies]) {
//            [storage deleteCookie:cookie];
//        }
//
//        /* iOS8.0 WebView cookies的存放路径 */
//        NSString *libraryDir = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) objectAtIndex:0];
//        NSString *webkitFolderInLib = [NSString stringWithFormat:@"%@/WebKit",libraryDir];
//        NSError *error;
//        [[NSFileManager defaultManager] removeItemAtPath:webkitFolderInLib error:&error];
//    }
}

- (void)removeUserScripts {
    [self.wkWebView.configuration.userContentController removeAllUserScripts];
    //设置H5的window浏览器类型，因为上一句remove了此处要加回去
    WKUserScript *script = [[WKUserScript alloc] initWithSource:@"window.iOSWebType='WKWebView';"
                                                  injectionTime:WKUserScriptInjectionTimeAtDocumentStart
                                               forMainFrameOnly:NO];
    [self.wkWebView.configuration.userContentController addUserScript:script];
}

#pragma mark 清除web缓存
- (void)removeCache {
    if (_webViewType == IQJWebViewType_UIWeb) {
        [[NSURLCache sharedURLCache] removeAllCachedResponses];
        NSURLCache * cache = [NSURLCache sharedURLCache];
        [cache removeAllCachedResponses];
        [cache setDiskCapacity:0];
        [cache setMemoryCapacity:0];
    } else if (_webViewType == IQJWebViewType_WKWeb) {
        if (@available(iOS 9.0, *)) {
            NSSet *cacheTypeSet = [NSSet setWithArray:@[WKWebsiteDataTypeDiskCache,
                                                         WKWebsiteDataTypeMemoryCache]];
            [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:cacheTypeSet
                                                       modifiedSince:[NSDate dateWithTimeIntervalSince1970:0]
                                                   completionHandler:^{
                                                       
                                                   }];
        } else {
            /* iOS8.0 WebView Cache的存放路径 */
            NSString *libraryDir = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) objectAtIndex:0];
            NSString *bundleId  =  [[[NSBundle mainBundle] infoDictionary]
                                    objectForKey:@"CFBundleIdentifier"];
            NSString *webKitFolderInCaches = [NSString
                                              stringWithFormat:@"%@/Caches/%@/WebKit",libraryDir,bundleId];
            NSError *error;
            [[NSFileManager defaultManager] removeItemAtPath:webKitFolderInCaches error:&error];
        }
    }
}


#pragma mark- UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSLog(@"\n\n\n当前是UIWEB\n\n\n");
    BOOL startBool = YES;
    if ([_delegate respondsToSelector:@selector(iqjWebViewShouldStartLoadURL:)]) {
        startBool = [_delegate iqjWebViewShouldStartLoadURL:request.URL];
    }
    return startBool;
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
    if ([_delegate respondsToSelector:@selector(iqjWebViewDidStartLoadURL:)]) {
        [_delegate iqjWebViewDidStartLoadURL:webView.request.URL];
    }
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self getDocumentTitle];
    if ([_delegate respondsToSelector:@selector(iqjWebViewDidFinishLoadURL:)]) {
        [_delegate iqjWebViewDidFinishLoadURL:webView.request.URL];
    }
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    if ([_delegate respondsToSelector:@selector(iqjWebViewURL:didFailLoadWithError:)]) {
        [_delegate iqjWebViewURL:webView.request.URL didFailLoadWithError:error];
    }
}


#pragma mark- WKNavigationDelegate
#pragma mark 在发送请求之前，决定是否跳转
/**
 *  在发送请求之前，决定是否跳转
 *  @param webView          实现该代理的webview
 *  @param navigationAction 导航信息
 *  @param decisionHandler  是否调转block
 */
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    NSLog(@"\n\n\n当前是WKWEB\n\n\n");
    NSLog(@"%s", __FUNCTION__);
    BOOL allowRequest = YES;
    if ([_delegate respondsToSelector:@selector(iqjWebViewShouldStartLoadURL:)]) {
        allowRequest = [_delegate iqjWebViewShouldStartLoadURL:navigationAction.request.URL];
    }
    if (allowRequest) {
        //如果目标frame不存在或不是主frame则使用原wkwebview重新reloadm，防止开启新网页
        if(!navigationAction.targetFrame || !navigationAction.targetFrame.isMainFrame) {
            [webView loadRequest:navigationAction.request];
        }
        decisionHandler(WKNavigationActionPolicyAllow);
    } else {
        decisionHandler(WKNavigationActionPolicyCancel);
    }
}

#pragma mark 在收到响应后，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    NSLog(@"%s", __FUNCTION__);
    //可以通过接受到的信息判断是否继续加载网页
    decisionHandler(WKNavigationResponsePolicyAllow);
}

#pragma mark 重定向跳转
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation {
    NSLog(@"%s", __FUNCTION__);
}

#pragma mark 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    NSLog(@"%s", __FUNCTION__);
    if ([_delegate respondsToSelector:@selector(iqjWebViewDidStartLoadURL:)]) {
        [_delegate iqjWebViewDidStartLoadURL:webView.URL];
    }
}

#pragma mark 解决内存消耗过大白屏问题
/** iOS 9以后 WKNavigtionDelegate 新增了一个回调函数：
 当 WKWebView 总体内存占用过大，页面即将白屏的时候，系统会调用上面的回调函数，我们在该函数里执行[webView reload](这个时候 webView.URL 取值尚不为 nil）解决白屏问题。在一些高内存消耗的页面可能会频繁刷新当前页面，H5侧也要做相应的适配操作。
 */
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {
    if (@available(iOS 9.0, *)) {
        [webView reload];
    }
}

#pragma mark 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    NSLog(@"%s", __FUNCTION__);
}

#pragma mark 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    NSLog(@"%s", __FUNCTION__);
    [self getDocumentTitle];
    if ([_delegate respondsToSelector:@selector(iqjWebViewDidFinishLoadURL:)]) {
        [_delegate iqjWebViewDidFinishLoadURL:webView.URL];
    }
}

#pragma mark 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"%s", __FUNCTION__);
    if ([_delegate respondsToSelector:@selector(iqjWebViewURL:didFailLoadWithError:)]) {
        [_delegate iqjWebViewURL:webView.URL didFailLoadWithError:error];
    }
}

#pragma mark 跳转失败时调用
- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"%s", __FUNCTION__);
    if ([_delegate respondsToSelector:@selector(iqjWebViewURL:didFailLoadWithError:)]) {
        [_delegate iqjWebViewURL:webView.URL didFailLoadWithError:error];
    }
}

#pragma mark- WKUIDelegate
/* 创建一个新的WebView */
- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures{
    NSLog(@"%s",__FUNCTION__);
    return webView;
}
/* 关闭WKWebView */
- (void)webViewDidClose:(WKWebView *)webView {
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  web界面中有弹出警告框Confirm时调用
 *  @param webView           实现该代理的webview
 *  @param message           警告框中的内容
 *  @param frame             主窗口
 *  @param completionHandler 警告框消失调用
 */
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler;{
    // 确定按钮
    UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }];
    // alert弹出框
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message message:nil preferredStyle:UIAlertControllerStyleAlert];
//    [alertController addAction:alertAction];
//    [self. presentViewController:alertController animated:YES completion:nil];
}

/* 接收到JS调用Confirm */
- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler {
    // 按钮
    UIAlertAction *alertActionCancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        // 返回用户选择的信息
        completionHandler(NO);
    }];
    UIAlertAction *alertActionOK = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }];
    // alert弹出框
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message message:nil preferredStyle:UIAlertControllerStyleAlert];
//    [alertController addAction:alertActionCancel];
//    [alertController addAction:alertActionOK];
//    [RootNC presentViewController:alertController animated:YES completion:nil];
}

/* TextInput输入框 */
- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(nonnull NSString *)prompt defaultText:(nullable NSString *)defaultText initiatedByFrame:(nonnull WKFrameInfo *)frame completionHandler:(nonnull void (^)(NSString * _Nullable))completionHandler {
    // alert弹出框
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:prompt message:nil preferredStyle:UIAlertControllerStyleAlert];
//    // 输入框
//    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
//        textField.placeholder = defaultText;
//    }];
//    // 确定按钮
//    [alertController addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//        // 返回用户输入的信息
//        UITextField *textField = alertController.textFields.firstObject;
//        completionHandler(textField.text);
//    }]];
//    // 显示
//    [RootNC presentViewController:alertController animated:YES completion:nil];
}


#pragma mark- Get
- (UIWebView *)uiWebView {
    if (!_uiWebView) {
        self.uiWebView = [[UIWebView alloc] initWithFrame:CGRectMake(0, kNavigationBarHeight, ScreenWidth, ScreenHeight - kNavigationBarHeight)];
        _uiWebView.dataDetectorTypes = UIDataDetectorTypeNone;//不响应界面的电话和链接
        _uiWebView.scalesPageToFit = YES;
        _uiWebView.opaque = NO;
        _uiWebView.scrollView.bounces = NO;
        _uiWebView.allowsInlineMediaPlayback = YES;
        _uiWebView.mediaPlaybackRequiresUserAction = NO;
        _uiWebView.delegate = self;
        [self resetUIWebViewUserAgent];
    }
    return _uiWebView;
}

- (WKWebView *)wkWebView {
    if (!_wkWebView) {
        self.wkWebView = [[WKWebView alloc] initWithFrame:CGRectMake(0, kNavigationBarHeight, ScreenWidth, ScreenHeight - kNavigationBarHeight)];
        _wkWebView.backgroundColor = [UIColor whiteColor];
        _wkWebView.opaque = NO;
        _wkWebView.scrollView.bounces = NO;
        _wkWebView.configuration.dataDetectorTypes = UIDataDetectorTypeNone;
        _wkWebView.configuration.allowsInlineMediaPlayback = YES;
        _wkWebView.configuration.mediaPlaybackRequiresUserAction = NO;
        _wkWebView.navigationDelegate = self;
        _wkWebView.UIDelegate = self;
    }
    return _wkWebView;
}

@end
