//
//  NSURLRequest+ignoreSSL.h
//  iqianjin
//
//  Created by jiangyu on 2019/6/27.
//  Copyright © 2019年 iqianjin. All rights reserved.
//  testjiang 忽略web的ssl，连罗莉代理访问不到https

#import <Foundation/Foundation.h>

@interface NSURLRequest (ignoreSSL)

+(BOOL)allowsAnyHTTPSCertificateForHost:(NSString*)host;

@end
