//
//  NSObject+createJSContext.h
//  iqianjin
//
//  Created by jiangyu on 2019/6/10.
//  Copyright © 2019年 iqianjin. All rights reserved.
//  解决webVIewDidFinishLoad：执行之前获取jscontext注入交互方法
/**
 js文件只需加载完毕就可执行oc的接口方法；
 而oc端要访问js的接口则可在webVIewDidFinishLoad中执行，完美解决接口访问时机的问题。
 */

#import <Foundation/Foundation.h>

@interface NSObject (createJSContext)

@end

