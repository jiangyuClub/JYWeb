//
//  IQJWebViewController.h
//  XXX
//
//  Created by XXX on 2018/12/24.
//  Copyright © 2018年 XXX. All rights reserved.
//  重构的浏览器VC

#import <UIKit/UIKit.h>
#import "MacroDefine.h"
@class IQJWebInteractionHandler;

@interface IQJWebViewController : UIViewController

@property (nonatomic, assign) IQJWebViewType webViewType;   /** webView类型 */
@property (nonatomic, strong) IQJWebInteractionHandler *interactionHandler; /** 交互handler：管理UIWeb和WK的交互，分享类目中用到这个类，只能放到.h */

/**
 发起请求：Url
 */
- (void)loadRequestWithUrl:(NSString *)urlStr;

/**
 发起请求，不带token：Url
 */
- (void)loadRequestNoTokenWithUrl:(NSString *)urlStr;

/**
 加载html
 */
- (void)loadHtml:(NSString *)html;

/**
 重置referrerUrl为currentUrl：进入app后点击取消（如登录页）返回web后不加载referrerUrl改加载当前url
 */
- (void)resetReferrerUrl;

/**
 初始化array并获取供JS调用的OC方法名list
 */
- (void)initInteractionMethodMArray;

- (void)reloadCurrentUrl;

/**
 获取当前浏览器view
 */
- (id)getWebView;

/**
 设置导航标题
 */
- (void)setWebTitle:(NSString *)title;

- (NSString *)getWebTitle;

/**
 存储刷新url
 */
- (void)saveReferrerUrl:(NSString *)referrerUrl;

/**
 获取当前web加载url
 */
- (NSString *)getCurrentUrl;

- (void)isHideNavBar:(BOOL)isHide;

/**
 push一个新的webVC
 */
- (void)pushNewWebWithUrl:(NSString *)urlStr;

/**
 关闭当前web页打开新的web页：华夏用到
 */
- (void)closeCurrentWebViewAndOpenNewWebViewWithUlr:(NSString *)url;

@end

