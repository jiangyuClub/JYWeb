//
//  IQJWebViewController.m
//  XXX
//
//  Created by XXX on 2018/12/24.
//  Copyright © 2018年 XXX. All rights reserved.
//

#import "IQJWebViewController.h"
#import "IQJWebViewHandler.h"
#import "IQJWebInteractionHandler.h"
#import "IQJWebViewController+interaction.h"
#import "IQJWebViewController+progress.h"

@interface IQJWebViewController ()<IQJWebViewDelegate>

@property (nonatomic, strong) IQJWebViewHandler *webViewHandler; /** 浏览器封装：管理UIWeb和WK */
@property (nonatomic, copy) NSString *fullTitle;            /** 完整标题，navbar显示的是截取的标题 */
@property (nonatomic, copy) NSString *referrerUrl;          /** 返回页面需要刷新的url */

@end

@implementation IQJWebViewController

#pragma mark- LifeCycle
- (void)dealloc {
    //WebVC销毁时，移除WK注册的JS交互方法
    [_interactionHandler removeWKScriptMessage];
    
    if (_webViewType == IQJWebViewType_WKWeb) {
        _webViewHandler.wkWebView.UIDelegate = nil;
        _webViewHandler.wkWebView.navigationDelegate = nil;
    } else if (_webViewType == IQJWebViewType_UIWeb) {
        _webViewHandler.uiWebView.delegate = nil;
    }
    
    [self removeProgressKVO];
    
    [self removeNotifications];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (!self) {
        return nil;
    }
    
    self.webViewHandler = [[IQJWebViewHandler alloc] init];
    self.interactionHandler = [[IQJWebInteractionHandler alloc] init];
    
    //初始化浏览器类型
    [self resetWebViewType];
    self.webViewHandler.webViewType = self.webViewType;
    self.webViewHandler.delegate = self;
    self.interactionHandler.weakWebVC = self;
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpViews];
    
    //设置JS交互配置
    [self initInteractionMethodMArray];
    [self.interactionHandler setJSInteractionConfig];
    
    [self addProgressKVO];
    
    [self addNotifications];
    
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //页面返回时刷新refferrerUrl
    [self reloadReferrerUrl];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self stopProgressAnimation];
}

- (void)addNotifications {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didCreateJavaScriptContext:) name:@"WebViewDidCreateJavaScriptContext" object:nil];
}

- (void)removeNotifications {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WebViewDidCreateJavaScriptContext" object:nil];
}

#pragma mark SubViews
- (void)setUpViews {
    self.view.backgroundColor = [UIColor whiteColor];
    
    //初始化webview
    [self.webViewHandler initWebViewOnView:self.view];
    
    //初始化进度条
    [self initProgressView];
    [self.view addSubview:self.progressView];
}

#pragma mark- Methods
#pragma mark 设置web浏览器类型
- (void)resetWebViewType {
    self.webViewType = IQJWebViewType_UIWeb;
}

#pragma mark 加载url
- (void)loadRequestWithUrl:(NSString *)urlStr {
    if (!urlStr || urlStr.length <= 0) {
        return;
    }
    
    [self.webViewHandler resetCurrentUrl:urlStr];
    [self.webViewHandler loadRequestWithUrl:urlStr];
    
//    [self startProgressAnimationZeroing:YES];
    
//    @weakify(self);
//    [self.networkHandler netGetCookiesCompletion:^(NSInteger code, NSString *msg, id body) {
//        @strongify(self);
//        if (code == 1 && [body isKindOfClass:[NSDictionary class]]) {
//            NSString *webToken = [NSString getAvailableString:body[@"h5token"]];
//            NSArray *mobileLoginCookies = body[@"mobileLoginCookies"];
//            if ((webToken && webToken.length > 0) || mobileLoginCookies) {
//                [self.webViewHandler setCookiesUrl:urlStr appToken:webToken webInfoArray:mobileLoginCookies];
//                [self.webViewHandler loadRequestWithUrl:urlStr];
//            } else {
//                //存储url当加载失败时重新发起请求
//                self.referrerUrl = urlStr;
//                [self showNoNetWorkViewAndStopProgressWithClickBlock:nil];
//            }
//        } else {
//            //存储url当加载失败时重新发起请求
//            self.referrerUrl = urlStr;
//            [self showNoNetWorkViewAndStopProgressWithClickBlock:nil];
//        }
//    }];
}

- (void)loadRequestNoTokenWithUrl:(NSString *)urlStr {
    if (!urlStr || urlStr.length <= 0) {
        return;
    }
    [self.webViewHandler loadRequestWithUrl:urlStr];
}

#pragma mark 重新加载当前url
- (void)reloadCurrentUrl {
    if (!_webViewHandler.currentUrl && _webViewHandler.currentUrl.length <= 0) {
        return;
    }
    [self loadRequestWithUrl:self.webViewHandler.currentUrl];
}

#pragma mark 加载referrerUrl
- (void)reloadReferrerUrl {
    if (!_referrerUrl && _referrerUrl.length <= 0) {
        return;
    }
    //在线客服跳转到选图片回来后不刷新
    if ([self.fullTitle containsString:@"在线客服"]) {
        return;
    }
    //bbs不刷新
    if ([self.referrerUrl containsString:@"bbs.XXX.com"]) {
        return;
    }
    [self loadRequestWithUrl:self.referrerUrl];
}

- (void)loadHtml:(NSString *)html {
    if (!html || html.length <= 0) {
        return;
    }
    [self.webViewHandler loadHtml:html];
}

#pragma mark 重置referrerUrl为currentUrl：进入app后点击取消（如登录页）返回web后不加载referrerUrl改加载当前url
- (void)resetReferrerUrl {
    self.referrerUrl = self.webViewHandler.currentUrl;
}

- (void)pushNewWebWithUrl:(NSString *)urlStr {
    if (!urlStr || urlStr.length <= 0) {
        return;
    }
    IQJWebViewController *nWebVC = [[IQJWebViewController alloc] init];
    [nWebVC loadRequestWithUrl:urlStr];
    [self.navigationController pushViewController:nWebVC animated:YES];
}


#pragma mark 返回事件2：如果可以返回则返回  bbs特殊处理，要清理缓存，否则返回上一页后消息数不变
- (void)backAction {
    if (self.webViewHandler.canGoBack) {
        if (self.webViewHandler.isLoading) {
            [self.navigationController popViewControllerAnimated:NO];
        } else {
            [self.webViewHandler goBack];
        }
    } else {
        [self.navigationController popViewControllerAnimated:NO];
    }
}

#pragma mark 获取当前浏览器view
- (id)getWebView {
    id webview = nil;
    if (_webViewType == IQJWebViewType_WKWeb) {
        webview = _webViewHandler.wkWebView;
    } else if (_webViewType == IQJWebViewType_UIWeb) {
        webview = _webViewHandler.uiWebView;
    }
    return webview;
}

#pragma mark 设置导航栏标题
- (void)setWebTitle:(NSString *)title {
    //"在线服务"标题不按web获取的title做更新
    if (![title containsString:@"在线客服"] && [self.fullTitle containsString:@"在线客服"]) {
        self.fullTitle = @"在线客服";
    } else {
        self.fullTitle = [title copy];
    }
    if (self.fullTitle) {
        //title过长则截取
        NSInteger titleLong = 12;
        NSString *title = self.fullTitle;
        if (title && title.length > titleLong) {
            NSString *formatTitle = [title substringToIndex:titleLong];
            title = [NSString stringWithFormat:@"%@...",formatTitle];
        }
        self.navigationController.title = title;
    }
}

- (NSString *)getWebTitle {
    return self.fullTitle;
}

- (NSString *)getCurrentUrl {
    return self.webViewHandler.currentUrl;
}

- (void)saveReferrerUrl:(NSString *)referrerUrl {
    if (referrerUrl && referrerUrl.length > 0) {
        self.referrerUrl = referrerUrl;
    }
}

#pragma mark 关闭当前web页打开新的web页：华夏用到
- (void)closeCurrentWebViewAndOpenNewWebViewWithUlr:(NSString *)url {
    if (_webViewType == IQJWebViewType_WKWeb) {
        [self.webViewHandler.wkWebView removeFromSuperview];
        self.webViewHandler.wkWebView = nil;
    } else if (_webViewType == IQJWebViewType_UIWeb) {
        [self.webViewHandler.uiWebView removeFromSuperview];
        self.webViewHandler.uiWebView = nil;
    }
    
    [self.webViewHandler initWebViewOnView:self.view];
    [self loadRequestWithUrl:url];
}

#pragma mark 白名单：过滤判断是否是需要过滤的url
- (BOOL)isBadUrlWithUrl:(NSString *)url {
    if (!url) {
        return NO;
    }
    return YES;
}


#pragma mark- IQJWebViewDelegate
- (BOOL)iqjWebViewShouldStartLoadURL:(NSURL *)URL {
    NSLog(@"\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^shouldStartLoadWithRequest:%@\n",URL);

    //拦截筛选URL，返回是否继续执行请求
    BOOL startBool = YES;
    
    //拦截处理完判断白名单
    if (startBool && [URL.absoluteString containsString:@"http"]) {
        startBool = ![self isBadUrlWithUrl:URL.absoluteString];
    }
    
    //白名单通过开启进度条
    if (startBool) {
        //开始进度条
        [self startProgressAnimationZeroing:NO];
    } else {
        //移除进度条
        [self stopProgressAnimation];
    }
    
    return startBool;
}

- (void)iqjWebViewDidStartLoadURL:(NSURL *)URL {
    NSLog(@"\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^DidStartLoad:%@\n",URL);
}

- (void)iqjWebViewDidFinishLoadURL:(NSURL *)URL {
    NSLog(@"\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^DidFinishLoad:%@\n",URL);
    
    
    [self stopProgressAnimation];
    
    [self setWebTitle:_webViewHandler.title];
    
    [self saveReferrerUrl:URL.absoluteString];

    //每次H5加载成功后更新JSContext
    [self.interactionHandler bindingJSContext];
}

- (void)iqjWebViewURL:(NSURL *)URL didFailLoadWithError:(NSError *)error {
    NSLog(@"\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^FailLoad:%@\nerror == > %@\n",URL,error);
    [self stopProgressAnimation];
    
    [self saveReferrerUrl:URL.absoluteString];
}

/**
 解决webViewDidFinishLoad：执行之前js代码调用交互方法无效
 js文件只需加载完毕，会收到这个通知，获取jscontext注入交互方法，就可执行oc的接口方法；
 而oc端要访问js的接口则可在webVIewDidFinishLoad中执行，完美解决接口访问时机的问题。
 */
- (void)didCreateJavaScriptContext:(NSNotification *)notifi {
    [self.interactionHandler bindingJSContext];
}

@end
