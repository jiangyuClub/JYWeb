//
//  IQJWebViewController+progress.m
//  XXX
//
//  Created by XXX on 2019/4/8.
//  Copyright © 2019年 XXX. All rights reserved.
//

#import "IQJWebViewController+progress.h"
#import <WebKit/WebKit.h>
#import "UIViewExt.h"

@implementation IQJWebViewController (progress)

- (void)initProgressView {
    if (!self.progressView) {
        self.progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(0, kNavigationBarHeight, ScreenWidth, 2)];
        self.progressView.trackTintColor = [UIColor grayColor];
        self.progressView.progressTintColor = [UIColor grayColor];
    }
}

- (void)refreshProgressView {
    self.progressView.top = kNavigationBarHeight;
}

#pragma mark- wk进度KVO
- (void)addProgressKVO {
    if (self.webViewType == IQJWebViewType_UIWeb) {
        return;
    }
    UIView *wkWeb = [self getWebView];
    [wkWeb addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
}

- (void)removeProgressKVO {
    if (self.webViewType == IQJWebViewType_UIWeb) {
        return;
    }
    UIView *wkWeb = [self getWebView];
    [wkWeb removeObserver:self forKeyPath:@"estimatedProgress"];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"estimatedProgress"]) {
        id webView = [self getWebView];
        if (![webView isKindOfClass:WKWebView.class]) {
            return;
        }
        self.progressView.progress = ((WKWebView *)webView).estimatedProgress;
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

#pragma mark- 进度条开启关闭
- (void)startProgressAnimationZeroing:(BOOL)zeroing {
    //开始展示progressView
    self.progressView.hidden = NO;
    self.progressView.height = 2;
    
    //防止progressView被网页挡住
    [self.view bringSubviewToFront:self.progressView];
    
    if (zeroing) {
        self.progressView.progress = 0;
    }
    
    [self startProgressTimer];
}

- (void)stopProgressAnimation {
    [self stopProgressTimer];
    
    if (!self.progressView || self.progressView.hidden) {
        return;
    }
    
    /*
     *添加一个简单的动画
     *动画时长0.25s，延时0.1s后开始动画
     *动画结束后将progressView隐藏
     */
    [UIView animateWithDuration:0.25f
          delay:0.1f
        options:UIViewAnimationOptionCurveEaseOut
     animations:^{
         self.progressView.height = 0;
     }
     completion:^(BOOL finished) {
         self.progressView.hidden = YES;
         self.progressView.progress = 0;
     }];
}

#pragma mark- UIWeb定时器
- (void)startProgressTimer {
    if (self.webViewType == IQJWebViewType_WKWeb) {
        return;
    }
    if (!self.progressTimer) {
        self.progressTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(resetTimerProgress) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:self.progressTimer forMode:NSRunLoopCommonModes];
    } else {
        [self.progressTimer fire];
    }
}

- (void)stopProgressTimer {
    if (self.webViewType == IQJWebViewType_WKWeb) {
        return;
    }
    if (self.progressTimer) {
        [self.progressTimer invalidate];
        self.progressTimer = nil;
    }
}

- (void)resetTimerProgress {
    if (self.progressView.progress >= 1) {
        [self stopProgressAnimation];
    } else {
        [UIView animateWithDuration:1
         animations:^{
             if (self.progressView.progress < 0.5) {
                 self.progressView.progress += 0.2;
             } else if (self.progressView.progress < 0.7) {
                 self.progressView.progress += 0.1;
             } else if (self.progressView.progress < 0.8) {
                 self.progressView.progress += 0.05;
             } else if (self.progressView.progress < 0.9) {
                 self.progressView.progress += 0.02;
             } else {
                 self.progressView.progress += 0.01;
             }
         }];
    }
}

@end
