//
//  IQJWebViewController+interaction.m
//  XXX
//
//  Created by XXX on 2019/4/8.
//  Copyright © 2019年 XXX. All rights reserved.
//

#import "IQJWebViewController+interaction.h"
#import "objc/runtime.h"

@implementation IQJWebViewController (interaction)

#pragma mark 初始化array并获取供JS调用的OC方法名list
- (void)initInteractionMethodMArray {
    self.exportMethodMArray = [NSMutableArray array];
    /* 获取方法列表描述 */
    unsigned int methodCount = 0;
    Method *method = class_copyMethodList(NSClassFromString(@"IQJWebMethodsHandler"), &methodCount);
    for (unsigned int i = 0; i < methodCount; i++) {
        Method me = method[i];
        if (!me) {
            continue;
        }
//        NSLog(@"方法名称----%@",NSStringFromSelector(method_getName(me)));
        NSString *methodName = NSStringFromSelector(method_getName(me));
        if (methodName && methodName.length >= 0) {
            [self.exportMethodMArray addObject:methodName];
        }
    }
    free(method);
}

@end
