//
//  IQJWebViewController+progress.h
//  XXX
//
//  Created by XXX on 2019/4/8.
//  Copyright © 2019年 XXX. All rights reserved.
//  进度条

#import "IQJWebViewController.h"

@interface IQJWebViewController ()

@property (nonatomic, strong) UIProgressView *progressView; /** 进度条 */
@property (nonatomic, strong) NSTimer *progressTimer;       /** UIWeb假进度定时器 */

@end

@interface IQJWebViewController (progress)

/**
 初始化进度条UI
 */
- (void)initProgressView;

/**
 刷新进度条frame
 */
- (void)refreshProgressView;

#pragma mark wk进度KVO
- (void)addProgressKVO;

- (void)removeProgressKVO;

/**
 开启进度条动画
 @param zeroing 是否从0开始
 */
- (void)startProgressAnimationZeroing:(BOOL)zeroing;

/**
 结束进度条动画
 */
- (void)stopProgressAnimation;

@end

