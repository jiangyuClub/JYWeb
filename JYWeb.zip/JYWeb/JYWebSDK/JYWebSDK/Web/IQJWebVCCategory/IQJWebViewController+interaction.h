//
//  IQJWebViewController+interaction.h
//  XXX
//
//  Created by XXX on 2019/4/8.
//  Copyright © 2019年 XXX. All rights reserved.
//  IQJWebViewController供内部调用的方法收到分类

#import "IQJWebViewController.h"

@interface IQJWebViewController ()

@property (nonatomic, strong) NSMutableArray *exportMethodMArray; /** 供JS调用的OC方法名list，交互的时候判断方法是否存在和处理冒号：用 */

@end

@interface IQJWebViewController (interaction)

/**
 初始化array并获取供JS调用的OC方法名list
 */
- (void)initInteractionMethodMArray;

- (void)reloadCurrentUrl;

/**
 获取当前浏览器view
 */
- (id)getWebView;

/**
 设置导航标题
 */
- (void)setWebTitle:(NSString *)title;

- (NSString *)getWebTitle;

/**
 存储刷新url
 */
- (void)saveReferrerUrl:(NSString *)referrerUrl;

/**
 获取当前web加载url
 */
- (NSString *)getCurrentUrl;

- (void)isHideNavBar:(BOOL)isHide;

/**
 push一个新的webVC
 */
- (void)pushNewWebWithUrl:(NSString *)urlStr;

/**
 关闭当前web页打开新的web页：华夏用到
 */
- (void)closeCurrentWebViewAndOpenNewWebViewWithUlr:(NSString *)url;

@end
