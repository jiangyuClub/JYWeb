//
//  IQJWebInteractionNotices.h
//  XXX
//
//  Created by XXX on 2019/4/22.
//  Copyright © 2019年 XXX. All rights reserved.
//  Web交互用到的通知

//DSBridge返回处理key
static NSString *kDSBridgeReturnValueKey = @"kDSBridgeReturnValueKey";
static NSString *kDSBridgeReturnValueUserInfoKey = @"kDSBridgeReturnValueUserInfoKey";
