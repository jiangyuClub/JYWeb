//
//  IQJWebMethodsHandler+dsBridge.m
//  XXX
//
//  Created by XXX on 2019/4/22.
//  Copyright © 2019年 XXX. All rights reserved.
//

#import "IQJWebMethodsHandler+dsBridge.h"
#import "IQJWebInteractionNotices.h"
#import "IQJWebViewController+interaction.h"

@implementation IQJWebMethodsHandler (dsBridge)

- (void)call:(NSString *)json {
    //  **** 这是在子线程中没有切换到主线程 ****
    if (!json || json.length <= 0) {
        return;
    }
    NSDictionary *dic = [IQJWebUtil getDictionaryFromJson:json];
    
    //方法名处理
    if (!dic || ![dic isKindOfClass:NSDictionary.class] || !dic[@"dsFunctionName"]) {
        return;
    }
    //dsbridge传过来的参数可能有命名空间，iOS需要过滤掉，aaa.nativeShareWithJson转成nativeShareWithJson
    NSString *methodName = nil;
    if ([dic[@"dsFunctionName"] containsString:@"."]) {
        NSRange methodRange = [dic[@"dsFunctionName"] rangeOfString:@"."];
        methodName = [dic[@"dsFunctionName"] substringFromIndex:methodRange.location + 1];
    } else {
        methodName = dic[@"dsFunctionName"];
    }
    //JS传递过来的方法名全都没有冒号:
    //app实现的方法(exportMethodMArray内)可能冒号
    if ([self.weakWebVC.exportMethodMArray containsObject:[NSString stringWithFormat:@"%@:",methodName]]) {
        methodName = [NSString stringWithFormat:@"%@:",methodName];
    }
    if (!methodName) {
        return;
    }
    SEL methodSEL = NSSelectorFromString(methodName);
    if (![self respondsToSelector:methodSEL]) {
        return;
    }
    
    //入参处理：目前支持解析json、string、number
    //最终发送消息的参数methodParam可能有4种：nil，number，string，dic（dic又分为：有回调函数无业务参数，有回调函数又有业务参数为string，有回调函数又有业务参数为dic）
    id methodParam = nil; //消息发送的入参
    NSMutableDictionary *paramMDic = [NSMutableDictionary dictionary];
    //如果参数data存在
    if (dic && dic[@"data"] && ![dic[@"data"] isKindOfClass:NSNull.class]) {
        id data = nil;
        //参数dic[@"data"]有可能是json、string或者number
        if ([dic[@"data"] isKindOfClass:NSString.class]) {
            data = [IQJWebUtil getDicOrStringFromJson:dic[@"data"]];
        } else {
            data = dic[@"data"];
        }
        if ([dic[@"data"] isKindOfClass:NSDictionary.class]) {
            data = dic[@"data"];
        }
        //如果参数是多个：dic
        if (data && [data isKindOfClass:NSDictionary.class]) {
            [paramMDic addEntriesFromDictionary:data];
            //回调处理：_dscbstub是DSBridge定义的js回调函数名对应key，把回调的JS方法名传到body里
            if (dic[@"_dscbstub"]) {
                [paramMDic setObject:dic[@"_dscbstub"] forKey:@"callBackFunction"];
            }
            methodParam = paramMDic;
        }//如果参数是单个：string或number
        else if (data) {
            //回调处理：_dscbstub是DSBridge定义的js回调函数名对应key，把回调的JS方法名传到body里
            if (dic[@"_dscbstub"]) {
                [paramMDic setObject:dic[@"_dscbstub"] forKey:@"callBackFunction"];
                [paramMDic setObject:data forKey:@"paramStr"];
                methodParam = paramMDic;
            } else {
                methodParam = data;
            }
        }
    }//如果参数data不存在，但是有返回function
    else if (dic[@"_dscbstub"]) {
        [paramMDic setObject:dic[@"_dscbstub"] forKey:@"callBackFunction"];
        methodParam = paramMDic;
    }
    
    //如果参数是dic需要转成json
    if ([methodParam isKindOfClass:NSDictionary.class]) {
        methodParam = [IQJWebUtil getJsonFromObject:methodParam];
    }
    
    //根据JS传递过来的方法名发送消息
    dispatch_async(dispatch_get_main_queue(), ^{
        [self performSelector:methodSEL withObject:methodParam];
    });
}

/**
 app调用js后回调处理
 */
- (void)returnValue:(NSString *)json {
    if (!json || json.length <= 0) {
        return;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:kDSBridgeReturnValueKey
                                                            object:nil
                                                          userInfo:@{kDSBridgeReturnValueUserInfoKey : json}];
    });
}


@end
