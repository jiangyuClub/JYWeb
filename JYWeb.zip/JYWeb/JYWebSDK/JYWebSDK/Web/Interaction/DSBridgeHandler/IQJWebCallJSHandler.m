//
//  IQJWebCallJSHandler.m
//  XXX
//
//  Created by XXX on 2019/4/19.
//  Copyright © 2019年 XXX. All rights reserved.
//

#import "IQJWebCallJSHandler.h"
#import "IQJWebInteractionHandler.h"
#import "IQJWebInteractionNotices.h"

@interface IQJWebCallJSHandler ()

@property (nonatomic, strong) NSMutableDictionary *callBackMDic; /** 存储回调block */
@property (nonatomic, assign) NSInteger callBackId;              /** callBackMDic对应的key：传递给JS，JS处理完回调returnValue方法并附带此参数 */

@end

@implementation IQJWebCallJSHandler

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:kDSBridgeReturnValueKey
                                                  object:nil];
}

- (instancetype)init {
    self = [super init];
    if (!self) {
        nil;
    }
    self.callBackId = 0;
    self.callBackMDic = [NSMutableDictionary dictionary];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(returnValueHandler:)
                                                 name:kDSBridgeReturnValueKey
                                               object:nil];
    
    return self;
}

#pragma mark 调用JS方法统一入口
- (void)callJSMethod:(NSString *)method param:(NSArray *)param completionHandler:(void (^)(id value))completionHandler {
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:@{@"method" : method}];
    if (param) {
        [dic setObject:[IQJWebUtil getJsonFromObject:param] forKey:@"data"];
    }
    if (completionHandler) {
        NSNumber *callBackKey = [NSNumber numberWithInteger:self.callBackId + 1];
        [self.callBackMDic setObject:completionHandler forKey:callBackKey];
        [dic setObject:callBackKey forKey:@"callbackId"];
    }
    //回调需要切换主线程，JSCore回到使用GCD异步切换主线程不行，所以改成这种
    [self performSelectorOnMainThread:@selector(jsFunctionOnMainThreadWithDic:) withObject:dic waitUntilDone:NO];
}

- (void)jsFunctionOnMainThreadWithDic:(NSDictionary *)dic {
    NSString *param = [IQJWebUtil getJsonFromObject:dic];
    if (self.weakInteractionHandler.weakWebVC.webViewType == IQJWebViewType_WKWeb) {
        WKWebView *wkWeb = (WKWebView *)[self.weakInteractionHandler.weakWebVC getWebView];
        NSString *jsActionStr = [NSString stringWithFormat:@"window._handleMessageFromNative(%@)",param];
        [wkWeb evaluateJavaScript:jsActionStr completionHandler:^(id _Nullable data, NSError * _Nullable error) {
            NSLog(@"我是WKweb：js返回结果：%@",data);
        }];
    } else if (self.weakInteractionHandler.weakWebVC.webViewType == IQJWebViewType_UIWeb) {
        JSValue *jsFunction = [self.weakInteractionHandler.jsContext objectForKeyedSubscript:@"_handleMessageFromNative"];
        if (jsFunction && param) {
            JSValue *resultValue = [jsFunction callWithArguments:@[param]];
            NSLog(@"我是UIweb：js返回结果：%@",[resultValue toString]);
        }
    }
}

#pragma mark 调用JS方法回调统一处理
- (void)returnValueHandler:(NSNotification *)notice {
    NSDictionary *info = [notice userInfo];
    if (!info) {
        return;
    }
    NSString *noticeValue = [info objectForKey:kDSBridgeReturnValueUserInfoKey];
    if (!noticeValue || noticeValue.length <= 0) {
        return;
    }
    NSDictionary *noticeDic = [IQJWebUtil getDictionaryFromJson:noticeValue];
    if (!noticeDic || !noticeDic[@"id"]) {
        return;
    }
    void (^ completionHandler)(NSString *  _Nullable)= self.callBackMDic[noticeDic[@"id"]];
    if (!completionHandler) {
        return;
    }
    completionHandler(noticeDic[@"data"]);
    if ([noticeDic[@"complete"] boolValue]) {
        [self.callBackMDic removeObjectForKey:noticeDic[@"id"]];
    }
}

@end
