//
//  IQJWebDSBridgeMethodsExport.h
//  XXX
//
//  Created by XXX on 2019/4/22.
//  Copyright © 2019年 XXX. All rights reserved.
//  交互协议：声明OC方法，供JS调取的，DSBridge用

#import <JavaScriptCore/JavaScriptCore.h>

@protocol IQJWebDSBridgeMethodsExport <NSObject, JSExport>

//此处不能用@optional

#pragma mark- DSBridge调用统一入口
- (void)call:(NSString *)json;

/**
 app调用js后回调方法
 */
- (void)returnValue:(NSString *)json;

@end
