//
//  IQJWebCallJSHandler.h
//  XXX
//
//  Created by XXX on 2019/4/19.
//  Copyright © 2019年 XXX. All rights reserved.
//  调用JS方法+DSBridge回调处理

#import <Foundation/Foundation.h>
#import "WebImportHeader.h"

@interface IQJWebCallJSHandler : NSObject

@property (nonatomic, weak) IQJWebInteractionHandler *weakInteractionHandler; /**  */

- (void)callJSMethod:(NSString *)method param:(NSArray *)param completionHandler:(void (^)(id value))completionHandler;

@end

