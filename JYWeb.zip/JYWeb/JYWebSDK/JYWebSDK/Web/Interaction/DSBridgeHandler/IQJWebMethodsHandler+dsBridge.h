//
//  IQJWebMethodsHandler+dsBridge.h
//  XXX
//
//  Created by XXX on 2019/4/22.
//  Copyright © 2019年 XXX. All rights reserved.
//  供JS调用的OC方法：dsBridge部分

#import "IQJWebMethodsHandler.h"
#import "IQJWebDSBridgeMethodsExport.h"

@interface IQJWebMethodsHandler (dsBridge)<IQJWebDSBridgeMethodsExport>

@end

