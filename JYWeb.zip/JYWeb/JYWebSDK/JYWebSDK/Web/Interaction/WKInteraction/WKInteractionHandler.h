//
//  WKInteractionHandler.h
//  XXX
//
//  Created by XXX on 2019/3/5.
//  Copyright © 2019年 XXX. All rights reserved.
//  WK的JS交互处理类

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>
#import "IQJWebMethodsHandler.h"

@interface WKInteractionHandler : NSObject<WKScriptMessageHandler>

@property (nonatomic, weak) IQJWebMethodsHandler *weakMethodHandler; /**  */

/**
 注册供JS调用的方法
 */
- (void)addJSMHWithWKWebView:(WKWebView *)wkWebView scriptMessageHandler:(id <WKScriptMessageHandler>)scriptMessageHandler;

/**
 移除供JS调用的方法
 */
- (void)removeJSMHWithWKWebView:(WKWebView *)wkWebView;

@end
