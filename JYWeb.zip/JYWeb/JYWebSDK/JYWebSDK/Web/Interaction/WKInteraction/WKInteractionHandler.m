//
//  WKInteractionHandler.m
//  XXX
//
//  Created by XXX on 2019/3/5.
//  Copyright © 2019年 XXX. All rights reserved.
//

#import "WKInteractionHandler.h"
#import "IQJWebViewController.h"
#import "IQJWebViewController+interaction.h"

@interface WKInteractionHandler()

@end

@implementation WKInteractionHandler

- (instancetype)init {
    self = [super init];
    if (!self) {
        return nil;
    }
    return self;
}

#pragma mark- OC接受JS方法调用处理WKScriptMessageHandler
/**
 接收到JS调用后经过简单处理，发送消息给weakMethodHandler
 */
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    if (!message.name) {
        return;
    }
    NSString *jsText = [NSString stringWithFormat:@"WK JS调用OC方法：%@ ，参数： %@",message.name,message.body];
    NSLog(@"%@",jsText);
    
    //JS传递过来的方法名message.name全都没有冒号:
    //app实现的方法(exportMethodMArray内)可能冒号也可能没有冒号
    NSString *messageName = nil;
    if ([self.weakMethodHandler.weakWebVC.exportMethodMArray containsObject:[NSString stringWithFormat:@"%@:",message.name]]) {
        messageName = [NSString stringWithFormat:@"%@:",message.name];
    } else if ([self.weakMethodHandler.weakWebVC.exportMethodMArray containsObject:message.name]) {
        messageName = message.name;
    }
    if (!messageName) {
        return;
    }
    SEL messageSEL = NSSelectorFromString(messageName);
    if (![self.weakMethodHandler respondsToSelector:messageSEL]) {
        return;
    }
    id messageBody = message.body ?: nil;
    
    //根据JS传递过来的方法名给weakMethodHandler发送消息
    [self.weakMethodHandler performSelector:messageSEL withObject:messageBody];
}

#pragma mark 注册OC方法供JS调取
- (void)addJSMHWithWKWebView:(WKWebView *)wkWebView scriptMessageHandler:(id <WKScriptMessageHandler>)scriptMessageHandler {
    WKUserContentController *userContentController = [wkWebView configuration].userContentController;
    //遍历exportMethodMArray中方法注册到WK中
    for (NSString *obj in self.weakMethodHandler.weakWebVC.exportMethodMArray) {
        if (!obj) {
            continue;
        }
        SEL sel = NSSelectorFromString(obj);
        if (![self.weakMethodHandler respondsToSelector:sel]) {
            continue;
        }
        //注册JS的方法名不能带冒号:
        //方法名去除冒号: 未避免方法有两个冒号，取第一个冒号前方法名
        NSMutableString *tempObj = [NSMutableString stringWithString:obj];
        if ([tempObj containsString:@":"]) {
            NSRange range = [tempObj rangeOfString:@":"];
            [tempObj replaceCharactersInRange:NSMakeRange(range.location, tempObj.length - range.location) withString:@""];
        }
        [userContentController addScriptMessageHandler:scriptMessageHandler name:tempObj];
    }
}

#pragma mark 移除OC方法
- (void)removeJSMHWithWKWebView:(WKWebView *)wkWebView {
    WKUserContentController *userContentController = [wkWebView configuration].userContentController;
    [self.weakMethodHandler.weakWebVC.exportMethodMArray enumerateObjectsUsingBlock:^(NSString *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (!obj) {
            *stop = YES;
        }
        SEL sel = NSSelectorFromString(obj);
        if (![self.weakMethodHandler respondsToSelector:sel]) {
            *stop = YES;
        }
        //去除冒号:
        NSMutableString *tempObj = [NSMutableString stringWithString:obj];
        if ([tempObj containsString:@":"]) {
            NSRange range = [tempObj rangeOfString:@":"];
            [tempObj replaceCharactersInRange:NSMakeRange(range.location, tempObj.length - range.location) withString:@""];
        }
        [userContentController removeScriptMessageHandlerForName:tempObj];
    }];
}

@end
