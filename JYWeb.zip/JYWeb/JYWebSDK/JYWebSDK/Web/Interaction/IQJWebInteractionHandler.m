//
//  IQJWebInteractionHandler.m
//  XXX
//
//  Created by XXX on 2019/3/5.
//  Copyright © 2019年 XXX. All rights reserved.
//

#import "IQJWebInteractionHandler.h"
#import "IQJWebCallJSHandler.h"

@interface IQJWebInteractionHandler ()

@property (nonatomic, strong) IQJWebCallJSHandler *callJSHandler;     /** 调用JS方法封装 */

@end

@implementation IQJWebInteractionHandler

- (instancetype)init {
    self = [super init];
    if (!self) {
        return nil;
    }
    [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"pass_appnav=1"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    return self;
}

- (void)setJSInteractionConfig {
    if (!_methodHandler) {
        self.methodHandler = [[IQJWebMethodsHandler alloc] init];
        self.methodHandler.weakWebVC = self.weakWebVC;
    }
    if (_weakWebVC.webViewType == IQJWebViewType_WKWeb) {
        [self setWKWebJSConfig];
    } else if (_weakWebVC.webViewType == IQJWebViewType_UIWeb) {
        [self bindingJSContext];
        //更新jsContext
        self.methodHandler.weakJSContext = self.jsContext;
    }
}

#pragma mark- 绑定JSCore
- (void)bindingJSContext {
    id webview = [_weakWebVC getWebView];
    if (![webview isKindOfClass:UIWebView.class]) {
        return;
    }
    
    // 关联 JSContext
    self.jsContext = [(UIWebView *)webview valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    self.jsContext[@"JSCore"] = self.methodHandler;

    // 打印异常
    self.jsContext.exceptionHandler = ^(JSContext *context, JSValue *exceptionValue){
        context.exception = exceptionValue;
        NSLog(@"JS异常：%@", [exceptionValue toString]);
    };
    
    //设置H5的window浏览器类型
    self.jsContext[@"iOSWebType"] = @"UIWebView";
}

- (void)setWKWebJSConfig {
    id webview = [_weakWebVC getWebView];
    if (![webview isKindOfClass:WKWebView.class]) {
        return;
    }
    
    if (!_wkNativeHandler) {
        self.wkNativeHandler = [[WKInteractionHandler alloc] init];
        self.wkNativeHandler.weakMethodHandler = self.methodHandler;
    }
    
    //WKUserContentController提供使用JavaScript注册script的方法
    [_wkNativeHandler addJSMHWithWKWebView:webview scriptMessageHandler:self.wkNativeHandler];
    
    //设置H5的window浏览器类型
    WKUserScript *script = [[WKUserScript alloc] initWithSource:@"window.iOSWebType='WKWebView';"
                                                  injectionTime:WKUserScriptInjectionTimeAtDocumentStart
                                               forMainFrameOnly:NO];
    [((WKWebView *)webview).configuration.userContentController addUserScript:script];
}

- (void)removeWKScriptMessage {
    id webview = [_weakWebVC getWebView];
    if (![webview isKindOfClass:WKWebView.class]) {
        return;
    }
    
    [_wkNativeHandler removeJSMHWithWKWebView:webview];
}

- (void)callJSMethod:(NSString *)method param:(NSArray *)param completionHandler:(void (^)(id value))completionHandler {
    [self.callJSHandler callJSMethod:method param:param completionHandler:completionHandler];
}

- (IQJWebCallJSHandler *)callJSHandler {
    if (!_callJSHandler) {
        self.callJSHandler = [[IQJWebCallJSHandler alloc] init];
        _callJSHandler.weakInteractionHandler = self;
    }
    return _callJSHandler;
}

@end
