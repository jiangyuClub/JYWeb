//
//  IQJWebMethodsHandler.h
//  XXX
//
//  Created by XXX on 2018/11/27.
//  Copyright © 2018年 XXX. All rights reserved.
//  供JS调用的OC方法实现类
//  UIWeb和WK统一调用本类，JSCore暴露给JS的类也是他
//  JScore交互在子线程，调用的方法需要切换主线程来操作UI

#import <Foundation/Foundation.h>
#import "IQJWebMethodsExport.h"
#import <WebKit/WebKit.h>
#import <JavaScriptCore/JavaScriptCore.h>
#import "IQJWebUtil.h"
#import "IQJWebViewController.h"

@interface IQJWebMethodsHandler : NSObject<IQJWebMethodsExport>

@property (nonatomic, weak) IQJWebViewController *weakWebVC;
@property (nonatomic, weak) JSContext *weakJSContext;         /** JSCore上线文 */

/**
 调用JS方法回调
 @param function 回调方法名
 @param param 回调json参数
 */
- (void)jsCallBackFunction:(NSString *)function param:(id)param notDeleteCallBack:(NSInteger)notDeleteCallBack;

@end
