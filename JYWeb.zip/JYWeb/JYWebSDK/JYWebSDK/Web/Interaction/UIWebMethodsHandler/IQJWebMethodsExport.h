//
//  IQJWebMethodsExport.h
//  XXX
//
//  Created by XXX on 2018/11/27.
//  Copyright © 2018年 XXX. All rights reserved.
//  交互协议：声明OC方法，供JS调取的

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>

@protocol IQJWebMethodsExport <NSObject, JSExport>

//此处不能用@optional
/**
 分享
 @param shareJson json：分享入参和回调方法名（对应key：@"callBackFunction"）
 */
- (void)nativeShareWithJson:(NSString *)shareJson;

@end

