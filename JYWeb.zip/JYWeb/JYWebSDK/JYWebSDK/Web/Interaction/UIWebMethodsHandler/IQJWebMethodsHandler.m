//
//  IQJWebMethodsHandler.m
//  XXX
//
//  Created by XXX on 2018/11/27.
//  Copyright © 2018年 XXX. All rights reserved.
//

#import "IQJWebMethodsHandler.h"
#import "IQJWebCallJSHandler.h"

@implementation IQJWebMethodsHandler

#pragma mark- ExportMethods


- (void)nativeShareWithJson:(NSString *)shareJson {
    NSLog(@"我是OC：收到js分享数据：%@", shareJson);
    NSDictionary *infoDic = [IQJWebUtil getDictionaryFromJson:shareJson];
    if (!infoDic || ![infoDic isKindOfClass:[NSDictionary class]] || infoDic.count <= 0) {
        return;
    }
    
    
    if ([infoDic.allKeys containsObject:@"callBackFunction"]) {
        NSString *backFunction = [infoDic objectForKey:@"callBackFunction"];
        NSMutableDictionary *shareResultMDic = [NSMutableDictionary dictionary];
        [shareResultMDic setObject:@(1) forKey:@"resultType"];
        [shareResultMDic setObject:@(1) forKey:@"shareChannel"];
        NSString *shareResultStr = [IQJWebUtil getJsonFromObject:shareResultMDic];
        NSInteger notDeleteCallBack = [[infoDic objectForKey:@"notDeleteCallBack"] integerValue];
        [self jsCallBackFunction:backFunction param:shareResultStr notDeleteCallBack:notDeleteCallBack];
    }
}


#pragma mark- JS回调
/** @param function 回调方法名
 @param argumentsDic 回调方法入参
 */
- (void)jsCallBackFunction:(NSString *)function param:(id)param notDeleteCallBack:(NSInteger)notDeleteCallBack {
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:@{@"function" : function}];
    if (param) {
        [dic setObject:param forKey:@"param"];
    }
    [dic setObject:@(notDeleteCallBack) forKey:@"notDeleteCallBack"];
    //回调需要切换主线程，JSCore回到使用GCD异步切换主线程不行，所以改成这种
    [self performSelectorOnMainThread:@selector(jsCallBackOnMainThreadWithDic:) withObject:dic waitUntilDone:NO];
}

- (void)jsCallBackOnMainThreadWithDic:(NSDictionary *)dic {
    NSString *function = dic[@"function"];
    id param = @"";
    if (dic[@"param"]) {
        param = dic[@"param"];
    }
    //调用js上的回调function，紧接着删除该function
    NSMutableString *jsActionStr = [NSMutableString stringWithFormat:@"%@(%@)",function, param];
    if ([dic[@"notDeleteCallBack"] integerValue] != 1) {
        [jsActionStr appendString:[NSString stringWithFormat:@";delete window.%@", function]];
    }
    if (self.weakWebVC.webViewType == IQJWebViewType_WKWeb) {
        WKWebView *wkWeb = (WKWebView *)[self.weakWebVC getWebView];
        [wkWeb evaluateJavaScript:jsActionStr completionHandler:^(id _Nullable data, NSError * _Nullable error) {
            NSLog(@"我是WKweb：js返回结果：%@",data);
        }];
    } else if (self.weakWebVC.webViewType == IQJWebViewType_UIWeb) {
        UIWebView *uiWeb = (UIWebView *)[self.weakWebVC getWebView];
        [uiWeb stringByEvaluatingJavaScriptFromString:jsActionStr];
    }
}

- (void)nativeIsIphoneX:(NSString *)json {
    NSDictionary *infoDic = [IQJWebUtil getDictionaryFromJson:json];
    if (!infoDic || ![infoDic isKindOfClass:[NSDictionary class]] || infoDic.count <= 0) {
        return;
    }
    if ([infoDic.allKeys containsObject:@"callBackFunction"]) {
        NSString *iphoneX = IPHONEX ? @"1" : @"0";
        NSString *backFunction = [infoDic objectForKey:@"callBackFunction"];
        NSMutableDictionary *shareResultMDic = [NSMutableDictionary dictionary];
        [shareResultMDic setObject:iphoneX forKey:@"isIphoneX"];
        NSString *shareResultStr = [IQJWebUtil getJsonFromObject:shareResultMDic];
        NSInteger notDeleteCallBack = [[infoDic objectForKey:@"notDeleteCallBack"] integerValue];
        [self jsCallBackFunction:backFunction param:shareResultStr notDeleteCallBack:notDeleteCallBack];
    }
}

@end
