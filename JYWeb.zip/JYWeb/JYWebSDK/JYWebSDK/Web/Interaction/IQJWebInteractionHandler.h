//
//  IQJWebInteractionHandler.h
//  XXX
//
//  Created by XXX on 2019/3/5.
//  Copyright © 2019年 XXX. All rights reserved.
//  JS与iOS交互管理器
//  分别管理UIWeb（JSCore）和WKWeb（Notro）与js的交互

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>
#import "IQJWebMethodsHandler.h"
#import "IQJWebViewController.h"
#import "WKInteractionHandler.h"

@interface IQJWebInteractionHandler : NSObject

@property (nonatomic, weak) IQJWebViewController *weakWebVC;          /** weak持有webView，避免循环引用，.m里会用到 */
@property (nonatomic, strong) JSContext *jsContext;                   /** JSCore上下文 */
@property (nonatomic, strong) IQJWebMethodsHandler *methodHandler;    /** oc方法实现类：JSContext开放类也是它，WK收到JS的调用信息调取此类处理业务逻辑 */
@property (nonatomic, strong) WKInteractionHandler *wkNativeHandler;  /** wkweb交互管理器 */


/**
 设置JS交互配置
 */
- (void)setJSInteractionConfig;

/**
 绑定更新JSContext
 */
- (void)bindingJSContext;

/**
 移除WK注册的JS调用方法
 */
- (void)removeWKScriptMessage;


- (void)callJSMethod:(NSString *)method param:(NSArray *)param completionHandler:(void (^)(id value))completionHandler;

@end

